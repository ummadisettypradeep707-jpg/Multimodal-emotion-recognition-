from langdetect import detect, DetectorFactory
from typing import Optional
from app.utils.logger import setup_logger

logger = setup_logger(__name__)
DetectorFactory.seed = 0


class LanguageDetectionService:
    """Service for detecting language from text"""

    SUPPORTED_LANGUAGES = ['en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'ja', 'ko', 'zh-cn', 'zh-tw']

    def detect(self, text: str) -> str:
        """
        Detect language of input text

        Args:
            text: Input text

        Returns:
            Language code
        """
        try:
            language = detect(text)
            logger.info(f"Detected language: {language}")
            return language
        except Exception as e:
            logger.warning(f"Language detection failed: {str(e)}, defaulting to English")
            return 'en'

    def is_english(self, text: str) -> bool:
        """
        Check if text is in English

        Args:
            text: Input text

        Returns:
            True if English, False otherwise
        """
        language = self.detect(text)
        return language == 'en'