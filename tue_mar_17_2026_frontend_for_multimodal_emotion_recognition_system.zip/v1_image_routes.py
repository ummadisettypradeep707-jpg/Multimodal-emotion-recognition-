from fastapi import APIRouter, HTTPException, File, UploadFile
from typing import Optional
import time
import tempfile
import os
from app.schemas.response_schemas import ImageAnalysisResponse
from app.processors.image_processor import ImageProcessor
from app.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter(prefix="/api", tags=["image"])

image_processor = ImageProcessor()


@router.post("/analyze-image", response_model=ImageAnalysisResponse)
async def analyze_image(
        file: UploadFile = File(...),
        detect_multiple_faces: bool = False
):
    """
    Analyze image for facial emotion recognition

    Args:
        file: Image file upload
        detect_multiple_faces: Whether to detect and analyze multiple faces

    Returns:
        ImageAnalysisResponse with emotion predictions
    """
    try:
        start_time = time.time()

        # Validate file
        valid_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
        if file.content_type not in valid_types:
            raise HTTPException(status_code=400, detail="Unsupported image format")

        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp:
            contents = await file.read()
            tmp.write(contents)
            tmp_path = tmp.name

        try:
            logger.info(f"Processing image file: {file.filename}")

            # Process image
            result = image_processor.process(tmp_path, detect_multiple_faces)

            # Prepare face results
            face_results = []
            for face in result.get('face_results', []):
                face_results.append({
                    'face_id': face['face_id'],
                    'emotion': face['emotion'],
                    'confidence': float(face['confidence']),
                    'bounding_box': face['bounding_box'],
                    'alternative_emotions': {k: float(v) for k, v in face['emotion_scores'].items()}
                })

            # Prepare response
            response = ImageAnalysisResponse(
                image_file=file.filename,
                faces_detected=result['faces_detected'],
                primary_emotion=result['primary_emotion'],
                overall_confidence=float(result['confidence']),
                face_results=face_results,
                processing_time_ms=float((time.time() - start_time) * 1000)
            )

            logger.info(
                f"Image analysis completed: {response.primary_emotion} ({response.overall_confidence:.3f}), faces: {response.faces_detected}")
            return response

        finally:
            # Clean up temporary file
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
                logger.debug(f"Cleaned up temporary file: {tmp_path}")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in image analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Image analysis error: {str(e)}")