from config import settings


def validate_file_size(file_size: int, file_type: str) -> bool:
    """Validate uploaded file size"""
    if file_type == 'audio':
        return file_size <= settings.MAX_AUDIO_FILE_SIZE
    elif file_type == 'image':
        return file_size <= settings.MAX_IMAGE_FILE_SIZE
    elif file_type == 'video':
        return file_size <= settings.MAX_VIDEO_FILE_SIZE
    return False


def validate_file_format(filename: str, file_type: str) -> bool:
    """Validate file format"""
    ext = filename.split('.')[-1].lower()

    if file_type == 'audio':
        return ext in settings.ALLOWED_AUDIO_FORMATS
    elif file_type == 'image':
        return ext in settings.ALLOWED_IMAGE_FORMATS
    elif file_type == 'video':
        return ext in settings.ALLOWED_VIDEO_FORMATS
    return False