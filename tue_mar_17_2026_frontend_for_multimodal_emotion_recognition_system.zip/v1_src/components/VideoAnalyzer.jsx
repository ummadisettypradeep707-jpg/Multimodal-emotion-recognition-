import React, { useContext, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useWebcam } from '../hooks/useWebcam';
import { connectVideoStream } from '../services/api';
import EmotionCard from './EmotionCard';
import { ThemeContext } from '../context/ThemeContext';

const VideoAnalyzer = () => {
  const { t } = useTranslation();
  const { isDarkMode } = useContext(ThemeContext);
  const { videoRef, isActive, startWebcam, stopWebcam } = useWebcam();
  const [wsConnection, setWsConnection] = useState(null);
  const [videoResult, setVideoResult] = useState(null);
  const [frameCount, setFrameCount] = useState(0);

  useEffect(() => {
    return () => {
      if (wsConnection) wsConnection.close();
      if (isActive) stopWebcam();
    };
  }, []);

  const handleStartCamera = async () => {
    await startWebcam();
    const ws = connectVideoStream(
      (data) => {
        if (data.type === 'emotion_result') {
          setVideoResult(data);
          setFrameCount(data.frame_id);
        }
      },
      (error) => console.error('WebSocket error:', error)
    );
    setWsConnection(ws);
  };

  const handleStopCamera = () => {
    stopWebcam();
    if (wsConnection) {
      wsConnection.close();
      setWsConnection(null);
    }
  };

  const sendFrame = () => {
    if (videoRef.current && wsConnection && wsConnection.readyState === WebSocket.OPEN) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(videoRef.current, 0, 0);
      
      canvas.toBlob((blob) => {
        const reader = new FileReader();
        reader.onload = () => {
          const base64 = reader.result.split(',')[1];
          wsConnection.send(JSON.stringify({
            type: 'video_frame',
            frame_data: base64,
            frame_id: frameCount,
          }));
        };
        reader.readAsDataURL(blob);
      });
    }
  };

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(sendFrame, 500);
      return () => clearInterval(interval);
    }
  }, [isActive, wsConnection, frameCount]);

  return (
    <div className={`p-6 rounded-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
      <h2 className={`text-2xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        🎥 {t('video_analysis')}
      </h2>

      <div className="space-y-4">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          className="w-full rounded-lg border-2 border-gray-400"
        />

        <div className="flex gap-2">
          <button
            onClick={handleStartCamera}
            disabled={isActive}
            className="flex-1 bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 disabled:opacity-50 transition"
          >
            {t('start_camera')}
          </button>
          <button
            onClick={handleStopCamera}
            disabled={!isActive}
            className="flex-1 bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 disabled:opacity-50 transition"
          >
            {t('stop_camera')}
          </button>
        </div>

        {videoResult && (
          <div className="space-y-4">
            <div className={`p-4 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} rounded-lg`}>
              <p className={`text-sm font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {t('detected_faces')}: {videoResult.faces_detected}
              </p>
            </div>

            {videoResult.face_results && videoResult.face_results.map((face, idx) => (
              <div key={idx} className={`p-4 border rounded-lg ${
                isDarkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-300 bg-gray-50'
              }`}>
                <h4 className={`font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Face {face.face_id}
                </h4>
                <EmotionCard emotion={face.emotion} confidence={face.confidence} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoAnalyzer;