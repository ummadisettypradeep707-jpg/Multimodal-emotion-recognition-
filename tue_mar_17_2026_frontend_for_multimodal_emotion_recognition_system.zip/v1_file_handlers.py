import os
import shutil
from pathlib import Path


class FileHandler:
    """Utility class for file operations"""

    @staticmethod
    def ensure_directory(path: str) -> None:
        """Create directory if it doesn't exist"""
        Path(path).mkdir(parents=True, exist_ok=True)

    @staticmethod
    def clean_file(file_path: str) -> None:
        """Delete file if it exists"""
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception as e:
            pass

    @staticmethod
    def get_file_size(file_path: str) -> int:
        """Get file size in bytes"""
        try:
            return os.path.getsize(file_path)
        except:
            return 0