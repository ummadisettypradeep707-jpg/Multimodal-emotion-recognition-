from fastapi import APIRouter, HTTPException
from typing import Optional
import time
from app.schemas.request_schemas import TextAnalysisRequest
from app.schemas.response_schemas import TextAnalysisResponse
from app.processors.text_processor import TextProcessor
from app.services.language_detection_service import LanguageDetectionService
from app.services.translation_service import TranslationService
from app.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter(prefix="/api", tags=["text"])

text_processor = TextProcessor()
language_detector = LanguageDetectionService()
translator = TranslationService()


@router.post("/analyze-text", response_model=TextAnalysisResponse)
async def analyze_text(request: TextAnalysisRequest):
    """
    Analyze text input for emotion recognition

    Args:
        request: TextAnalysisRequest containing text and optional language

    Returns:
        TextAnalysisResponse with emotion predictions
    """
    try:
        start_time = time.time()

        logger.info(f"Processing text analysis request: {request.text[:100]}...")

        # Detect language if not provided
        detected_language = request.language or text_processor.detect_language(request.text)

        # Translate if needed
        translated_text = None
        if detected_language != 'en' and detected_language in ['es', 'fr', 'de', 'it', 'pt']:
            try:
                translated_text = translator.translate(request.text, detected_language, 'en')
                analysis_text = translated_text
                logger.info(f"Translated text from {detected_language} to English")
            except Exception as e:
                logger.warning(f"Translation failed: {str(e)}, using original text")
                analysis_text = request.text
                translated_text = None
        else:
            analysis_text = request.text

        # Process text
        result = text_processor.process(analysis_text)

        # Prepare response
        response = TextAnalysisResponse(
            emotion=result['primary_emotion'],
            confidence=float(result['confidence']),
            alternative_emotions={k: float(v) for k, v in result['emotion_scores'].items()},
            text=request.text,
            language=detected_language,
            translated_text=translated_text,
            processing_time_ms=float((time.time() - start_time) * 1000)
        )

        logger.info(f"Text analysis completed: {response.emotion} ({response.confidence:.3f})")
        return response

    except Exception as e:
        logger.error(f"Error in text analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Text analysis error: {str(e)}")