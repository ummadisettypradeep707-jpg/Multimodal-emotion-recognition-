from dotenv import load_dotenv
from os import getenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging
from config import settings
from app.utils.logger import setup_logger
from app.api import text_routes, audio_routes, image_routes, fusion_routes, health_routes
from app.websocket.audio_stream_handler import AudioStreamHandler
from app.websocket.video_stream_handler import VideoStreamHandler


load_dotenv()  # reads .env file

print(getenv("APP_ENV"))   # prints "development"
print(getenv("DEBUG"))     # prints "True"
print(getenv("WORKERS"))   # prints "4"
print(getenv("LOG_LEVEL")) # prints "INFO"

# Setup logger
logger = setup_logger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    description="Multimodal Emotion Recognition Server",
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Initialize handlers
audio_stream_handler = AudioStreamHandler()
video_stream_handler = VideoStreamHandler()

# Include routers
app.include_router(health_routes.router)
app.include_router(text_routes.router)
app.include_router(audio_routes.router)
app.include_router(image_routes.router)
app.include_router(fusion_routes.router)


# WebSocket endpoints
@app.websocket("/ws/live-audio")
async def websocket_audio_endpoint(websocket):
    """WebSocket endpoint for live audio streaming"""
    await audio_stream_handler.handle_connection(websocket)


@app.websocket("/ws/live-video")
async def websocket_video_endpoint(websocket):
    """WebSocket endpoint for live video streaming"""
    await video_stream_handler.handle_connection(websocket)


@app.on_event("startup")
async def startup_event():
    """Startup event handler"""
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    logger.info(f"Environment: {settings.APP_ENV}")
    logger.info(f"Debug mode: {settings.DEBUG}")
    logger.info(f"Workers: {settings.WORKERS}")


@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event handler"""
    logger.info(f"Shutting down {settings.APP_NAME}")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
        "health": "/health"
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        workers=settings.WORKERS,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )