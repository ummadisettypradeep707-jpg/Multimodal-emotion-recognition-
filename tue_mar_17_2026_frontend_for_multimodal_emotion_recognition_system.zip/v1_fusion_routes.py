from fastapi import APIRouter, HTTPException
import time
from app.schemas.request_schemas import FusionRequest
from app.schemas.response_schemas import FusionResponse
from app.processors.fusion_processor import FusionProcessor
from app.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter(prefix="/api", tags=["fusion"])

fusion_processor = FusionProcessor()


@router.post("/fusion", response_model=FusionResponse)
async def fuse_emotions(request: FusionRequest):
    """Fuse emotions from multiple modalities"""
    try:
        start_time = time.time()

        result = fusion_processor.process(request.dict(), request.fusion_mode)

        response = FusionResponse(
            final_emotion=result['final_emotion'],
            final_confidence=float(result['final_confidence']),
            modality_results=result['modality_results'],
            fusion_weights=result['fusion_weights'],
            processing_time_ms=float((time.time() - start_time) * 1000)
        )

        return response
    except Exception as e:
        logger.error(f"Error in fusion: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))