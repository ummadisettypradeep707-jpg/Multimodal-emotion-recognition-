import asyncio
import json
import base64
import numpy as np
from typing import Dict, Optional
import librosa
from fastapi import WebSocket, WebSocketDisconnect
from app.processors.audio_processor import AudioProcessor
from app.utils.logger import setup_logger

logger = setup_logger(__name__)


class AudioStreamHandler:
    """Handle real-time audio streaming via WebSocket"""

    def __init__(self):
        self.audio_processor = AudioProcessor()
        self.audio_chunks = []
        self.sample_rate = 16000
        self.chunk_duration = 1.0

    async def handle_connection(self, websocket: WebSocket):
        """
        Handle WebSocket connection for audio streaming

        Args:
            websocket: WebSocket connection object
        """
        await websocket.accept()
        logger.info("WebSocket audio connection established")

        chunk_id = 0
        audio_buffer = []

        try:
            while True:
                # Receive message from client
                data = await websocket.receive_text()
                message = json.loads(data)

                if message['type'] == 'audio_chunk':
                    chunk_id = message.get('chunk_id', 0)

                    # Decode base64 audio data
                    try:
                        audio_data = base64.b64decode(message['audio_data'])
                        audio_array = np.frombuffer(audio_data, dtype=np.float32)
                        audio_buffer.append(audio_array)

                        logger.debug(f"Received audio chunk {chunk_id}, size: {len(audio_data)} bytes")

                        # If this is a final chunk or buffer is large enough, process
                        if message.get('is_final', False) or len(audio_buffer) >= 16:
                            # Concatenate audio chunks
                            combined_audio = np.concatenate(audio_buffer)

                            # Extract features
                            mfcc = self.audio_processor.extract_mfcc(combined_audio, self.sample_rate)
                            spectral_features = self.audio_processor.extract_spectral_features(
                                combined_audio, self.sample_rate
                            )

                            # Convert features to emotions
                            features = {
                                'mfcc_mean': np.mean(mfcc, axis=1).tolist(),
                                'spectral_features': spectral_features,
                                'duration_seconds': len(combined_audio) / self.sample_rate
                            }

                            emotion_scores = self.audio_processor.features_to_emotion(features)
                            primary_emotion = max(emotion_scores, key=emotion_scores.get)
                            confidence = emotion_scores[primary_emotion]

                            # Send emotion result
                            result = {
                                'type': 'emotion_result',
                                'chunk_id': chunk_id,
                                'emotion': primary_emotion,
                                'confidence': float(confidence),
                                'emotion_scores': {k: float(v) for k, v in emotion_scores.items()}
                            }

                            await websocket.send_text(json.dumps(result))
                            logger.info(f"Sent emotion result: {primary_emotion} ({confidence:.3f})")

                            # Clear buffer if final chunk
                            if message.get('is_final', False):
                                audio_buffer = []

                    except Exception as e:
                        error_msg = {
                            'type': 'error',
                            'message': f"Error processing audio chunk: {str(e)}"
                        }
                        await websocket.send_text(json.dumps(error_msg))
                        logger.error(f"Error processing audio chunk: {str(e)}")

        except WebSocketDisconnect:
            logger.info("WebSocket audio connection closed")
        except Exception as e:
            logger.error(f"WebSocket error: {str(e)}")
            try:
                await websocket.close(code=1011, reason=str(e))
            except:
                pass