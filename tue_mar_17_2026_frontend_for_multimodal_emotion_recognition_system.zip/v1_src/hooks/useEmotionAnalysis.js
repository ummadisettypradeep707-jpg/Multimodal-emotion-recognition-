import { useState, useCallback } from 'react';
import { analyzeText, analyzeAudio, analyzeImage } from '../services/api';

export const useEmotionAnalysis = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const analyzeTextEmotion = useCallback(async (text, language) => {
    setLoading(true);
    setError(null);
    try {
      const response = await analyzeText(text, language);
      setResult(response.data);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.detail || 'Error analyzing text');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const analyzeAudioFile = useCallback(async (file) => {
    setLoading(true);
    setError(null);
    try {
      const response = await analyzeAudio(file);
      setResult(response.data);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.detail || 'Error analyzing audio');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const analyzeImageFile = useCallback(async (file, detectMultiple) => {
    setLoading(true);
    setError(null);
    try {
      const response = await analyzeImage(file, detectMultiple);
      setResult(response.data);
      return response.data;
    } catch (err) {
      setError(err.response?.data?.detail || 'Error analyzing image');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    result,
    analyzeTextEmotion,
    analyzeAudioFile,
    analyzeImageFile,
  };
};