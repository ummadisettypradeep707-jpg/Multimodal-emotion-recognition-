import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'
import TabNavigation from './TabNavigation'
import TextTab from './tabs/TextTab'
import AudioTab from './tabs/AudioTab'
import ImageTab from './tabs/ImageTab'
import VideoTab from './tabs/VideoTab'
import FusionTab from './tabs/FusionTab'
import HistoryTab from './tabs/HistoryTab'

const Dashboard = () => {
  const { t } = useTranslation()
  const [activeTab, setActiveTab] = useState('text')

  const tabs = [
    { id: 'text', label: t('tabs.text') },
    { id: 'audio', label: t('tabs.audio') },
    { id: 'image', label: t('tabs.image') },
    { id: 'video', label: t('tabs.video') },
    { id: 'fusion', label: t('tabs.fusion') },
    { id: 'history', label: t('tabs.history') },
  ]

  const renderTabContent = () => {
    switch (activeTab) {
      case 'text':
        return <TextTab />
      case 'audio':
        return <AudioTab />
      case 'image':
        return <ImageTab />
      case 'video':
        return <VideoTab />
      case 'fusion':
        return <FusionTab />
      case 'history':
        return <HistoryTab />
      default:
        return <TextTab />
    }
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-light-text dark:text-dark-text mb-2">
            {t('app.title')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">{t('app.subtitle')}</p>
        </div>

        {/* Tab Navigation */}
        <TabNavigation tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="mt-8"
        >
          {renderTabContent()}
        </motion.div>
      </div>
    </div>
  )
}

export default Dashboard