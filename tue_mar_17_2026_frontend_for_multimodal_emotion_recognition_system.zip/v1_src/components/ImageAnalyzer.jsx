import React, { useContext, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useEmotionAnalysis } from '../hooks/useEmotionAnalysis';
import EmotionCard from './EmotionCard';
import ConfidenceChart from './ConfidenceChart';
import { ThemeContext } from '../context/ThemeContext';

const ImageAnalyzer = () => {
  const { t } = useTranslation();
  const { isDarkMode } = useContext(ThemeContext);
  const [imageFile, setImageFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [detectMultiple, setDetectMultiple] = useState(false);
  const { loading, error, result, analyzeImageFile } = useEmotionAnalysis();

  const handleFileUpload = (file) => {
    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setPreview(reader.result);
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (imageFile) {
      await analyzeImageFile(imageFile, detectMultiple);
    }
  };

  return (
    <div className={`p-6 rounded-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
      <h2 className={`text-2xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        🖼️ {t('image_analysis')}
      </h2>

      <div className="space-y-4">
        {/* File Upload */}
        <div className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer ${
          isDarkMode ? 'border-gray-600 hover:bg-gray-700' : 'border-gray-300 hover:bg-gray-50'
        } transition`}>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => e.target.files && handleFileUpload(e.target.files[0])}
            className="hidden"
            id="image-upload"
          />
          <label htmlFor="image-upload" className="cursor-pointer block">
            <p className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {t('upload_file')}
            </p>
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {imageFile?.name || 'No image selected'}
            </p>
          </label>
        </div>

        {/* Image Preview */}
        {preview && (
          <img
            src={preview}
            alt="Preview"
            className="w-full max-h-64 object-cover rounded-lg"
          />
        )}

        {/* Multiple Faces Detection */}
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={detectMultiple}
            onChange={(e) => setDetectMultiple(e.target.checked)}
            className="rounded"
          />
          <span className={isDarkMode ? 'text-white' : 'text-gray-900'}>
            Detect Multiple Faces
          </span>
        </label>

        {/* Analyze Button */}
        <button
          onClick={handleAnalyze}
          disabled={loading || !imageFile}
          className="w-full bg-primary text-white py-2 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 transition"
        >
          {loading ? t('analyzing') : t('submit')}
        </button>
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
          {t('error')}: {error}
        </div>
      )}

      {result && (
        <div className="mt-6 space-y-4">
          <div className={`p-4 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} rounded-lg`}>
            <p className={isDarkMode ? 'text-white' : 'text-gray-900'}>
              {t('detected_faces')}: {result.faces_detected}
            </p>
          </div>

          {result.face_results && result.face_results.length > 0 ? (
            result.face_results.map((face, idx) => (
              <div key={idx} className={`p-4 border rounded-lg ${
                isDarkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-300 bg-gray-50'
              }`}>
                <h4 className={`font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Face {face.face_id}
                </h4>
                <EmotionCard emotion={face.emotion} confidence={face.confidence} />
              </div>
            ))
          ) : (
            <EmotionCard emotion={result.primary_emotion} confidence={result.overall_confidence} />
          )}

          <ConfidenceChart emotions={result.alternative_emotions || result.face_results?.[0]?.alternative_emotions} />
        </div>
      )}
    </div>
  );
};

export default ImageAnalyzer;