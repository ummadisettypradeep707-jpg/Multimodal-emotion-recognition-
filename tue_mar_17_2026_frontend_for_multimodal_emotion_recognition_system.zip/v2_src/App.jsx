import React from 'react';
import { useTranslation } from 'react-i18next';
import { ThemeProvider, ThemeContext } from './context/ThemeContext';
import Header from './components/Header';
import TextAnalyzer from './components/TextAnalyzer';
import AudioAnalyzer from './components/AudioAnalyzer';
import ImageAnalyzer from './components/ImageAnalyzer';
import VideoAnalyzer from './components/VideoAnalyzer';
import './App.css';

function AppContent() {
  const { isDarkMode } = React.useContext(ThemeContext);

  return (
    <div className={isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'} style={{ minHeight: '100vh' }}>
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Text Analysis */}
          <TextAnalyzer />
          
          {/* Audio Analysis */}
          <AudioAnalyzer />
          
          {/* Image Analysis */}
          <ImageAnalyzer />
          
          {/* Video Analysis */}
          <VideoAnalyzer />
        </div>

        {/* Footer */}
        <footer className={`mt-12 pt-8 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}>
          <p className={`text-center text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            © 2026 Multimodal Emotion Recognition System. Built with ❤️
          </p>
        </footer>
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;