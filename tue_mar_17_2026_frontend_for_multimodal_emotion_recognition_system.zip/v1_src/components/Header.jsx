import React from 'react'
import { useTranslation } from 'react-i18next'
import { MdBrightness4, MdBrightness7 } from 'react-icons/md'
import LanguageSwitcher from './LanguageSwitcher'

const Header = ({ isDark, onThemeToggle }) => {
  const { t } = useTranslation()

  return (
    <header className="sticky top-0 z-50 bg-light-card dark:bg-dark-card border-b border-light-border dark:border-dark-border shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Title */}
          <div className="flex items-center gap-3">
            <div className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              🎭 {t('app.title')}
            </div>
          </div>

          {/* Right side controls */}
          <div className="flex items-center gap-6">
            <LanguageSwitcher />

            {/* Theme Toggle */}
            <button
              onClick={onThemeToggle}
              className="p-2 rounded-lg hover:bg-light-border dark:hover:bg-dark-border transition-colors duration-200"
              aria-label="Toggle theme"
            >
              {isDark ? (
                <MdBrightness7 className="text-xl text-yellow-400" />
              ) : (
                <MdBrightness4 className="text-xl text-gray-600" />
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header