import { create } from 'zustand'

export const useEmotionStore = create((set, get) => ({
  history: JSON.parse(localStorage.getItem('emotionHistory')) || [],
  
  addToHistory: (emotion) => {
    set((state) => {
      const newHistory = [
        {
          id: Date.now(),
          timestamp: new Date().toISOString(),
          ...emotion,
        },
        ...state.history.slice(0, 49), // Keep last 50 items
      ]
      localStorage.setItem('emotionHistory', JSON.stringify(newHistory))
      return { history: newHistory }
    })
  },

  clearHistory: () => {
    localStorage.removeItem('emotionHistory')
    set({ history: [] })
  },

  getHistory: () => get().history,
}))