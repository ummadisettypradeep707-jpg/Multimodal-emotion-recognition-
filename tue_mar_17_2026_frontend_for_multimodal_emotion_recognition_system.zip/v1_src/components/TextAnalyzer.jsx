import React, { useState, useContext } from 'react';
import { useTranslation } from 'react-i18next';
import { useEmotionAnalysis } from '../hooks/useEmotionAnalysis';
import EmotionCard from './EmotionCard';
import ConfidenceChart from './ConfidenceChart';
import { ThemeContext } from '../context/ThemeContext';

const TextAnalyzer = () => {
  const { t } = useTranslation();
  const { isDarkMode } = useContext(ThemeContext);
  const [text, setText] = useState('');
  const { loading, error, result, analyzeTextEmotion } = useEmotionAnalysis();

  const handleAnalyze = async (e) => {
    e.preventDefault();
    if (text.trim()) {
      await analyzeTextEmotion(text);
    }
  };

  return (
    <div className={`p-6 rounded-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
      <h2 className={`text-2xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        📝 {t('text_analysis')}
      </h2>

      <form onSubmit={handleAnalyze} className="space-y-4">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Enter text for emotion analysis..."
          className={`w-full p-4 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary ${
            isDarkMode
              ? 'bg-gray-700 text-white border-gray-600'
              : 'bg-white text-gray-900 border-gray-300'
          }`}
          rows="4"
        />

        <div className="flex gap-2">
          <button
            type="submit"
            disabled={loading || !text.trim()}
            className="flex-1 bg-primary text-white py-2 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 transition"
          >
            {loading ? t('analyzing') : t('submit')}
          </button>
          <button
            type="button"
            onClick={() => setText('')}
            className="flex-1 bg-gray-400 text-white py-2 px-4 rounded-lg hover:bg-gray-500 transition"
          >
            {t('clear')}
          </button>
        </div>
      </form>

      {error && (
        <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
          {t('error')}: {error}
        </div>
      )}

      {result && (
        <div className="mt-6 space-y-4">
          <EmotionCard emotion={result.emotion} confidence={result.confidence} />
          <ConfidenceChart emotions={result.alternative_emotions} />
        </div>
      )}
    </div>
  );
};

export default TextAnalyzer;