# Emotion Labels
EMOTION_LABELS = {
    'text': ['anger', 'fear', 'joy', 'sadness', 'neutral', 'surprise', 'disgust'],
    'audio': ['angry', 'fearful', 'happy', 'sad', 'neutral', 'surprised', 'disgusted'],
    'image': ['angry', 'fearful', 'happy', 'sad', 'neutral', 'surprised', 'disgusted']
}

# Supported Languages
SUPPORTED_LANGUAGES = [
    'en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'ja', 'ko', 'zh'
]

# WebSocket Message Types
WS_MESSAGE_TYPES = {
    'AUDIO_CHUNK': 'audio_chunk',
    'VIDEO_FRAME': 'video_frame',
    'EMOTION_RESULT': 'emotion_result',
    'ERROR': 'error',
    'HEARTBEAT': 'heartbeat'
}

# Confidence Thresholds
MIN_CONFIDENCE_THRESHOLD = 0.3
HIGH_CONFIDENCE_THRESHOLD = 0.8

# Cache TTL
MODEL_CACHE_TTL = 3600  # 1 hour
EMOTION_CACHE_TTL = 300  # 5 minutes