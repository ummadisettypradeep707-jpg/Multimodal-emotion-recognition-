import axios from 'axios'

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error)
    return Promise.reject(error)
  }
)

export const textAnalysis = async (text, language = null) => {
  try {
    const response = await apiClient.post('/analyze-text', {
      text,
      language,
    })
    return response.data
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Text analysis failed')
  }
}

export const audioAnalysis = async (audioFile) => {
  try {
    const formData = new FormData()
    formData.append('file', audioFile)

    const response = await axios.post(
      `${API_BASE_URL}/analyze-audio`,
      formData,
      {
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 60000,
      }
    )
    return response.data
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Audio analysis failed')
  }
}

export const imageAnalysis = async (imageFile, detectMultipleFaces = false) => {
  try {
    const formData = new FormData()
    formData.append('file', imageFile)
    formData.append('detect_multiple_faces', detectMultipleFaces)

    const response = await axios.post(
      `${API_BASE_URL}/analyze-image`,
      formData,
      {
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 60000,
      }
    )
    return response.data
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Image analysis failed')
  }
}

export const fusionAnalysis = async (modalityResults, fusionMode = 'weighted') => {
  try {
    const response = await apiClient.post('/fusion', {
      ...modalityResults,
      fusion_mode: fusionMode,
    })
    return response.data
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Fusion analysis failed')
  }
}

export const healthCheck = async () => {
  try {
    const response = await apiClient.get('/health')
    return response.data
  } catch (error) {
    throw new Error('Health check failed')
  }
}

export default apiClient