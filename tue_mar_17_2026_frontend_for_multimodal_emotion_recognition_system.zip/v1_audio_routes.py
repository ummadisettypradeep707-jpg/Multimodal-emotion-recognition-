from fastapi import APIRouter, HTTPException, File, UploadFile
from typing import Optional
import time
import tempfile
import os
from app.schemas.response_schemas import AudioAnalysisResponse
from app.processors.audio_processor import AudioProcessor
from app.utils.logger import setup_logger
from config import settings

logger = setup_logger(__name__)
router = APIRouter(prefix="/api", tags=["audio"])

audio_processor = AudioProcessor()


@router.post("/analyze-audio", response_model=AudioAnalysisResponse)
async def analyze_audio(file: UploadFile = File(...)):
    """
    Analyze audio file for emotion recognition

    Args:
        file: Audio file upload

    Returns:
        AudioAnalysisResponse with emotion predictions
    """
    try:
        start_time = time.time()

        # Validate file
        if file.content_type not in ['audio/mpeg', 'audio/wav', 'audio/mp4', 'audio/ogg']:
            raise HTTPException(status_code=400, detail="Unsupported audio format")

        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
            contents = await file.read()
            tmp.write(contents)
            tmp_path = tmp.name

        try:
            logger.info(f"Processing audio file: {file.filename}")

            # Process audio
            result = audio_processor.process(tmp_path)

            # Prepare response
            response = AudioAnalysisResponse(
                emotion=result['primary_emotion'],
                confidence=float(result['confidence']),
                alternative_emotions={k: float(v) for k, v in result['emotion_scores'].items()},
                audio_file=file.filename,
                duration_seconds=float(result['features']['duration_seconds']),
                features_extracted={
                    'mfcc_mean': [float(x) for x in result['features']['mfcc_mean']],
                    'mfcc_std': [float(x) for x in result['features']['mfcc_std']],
                    'spectral_features': {k: float(v) for k, v in result['features']['spectral_features'].items()},
                    'temporal_features': {k: float(v) for k, v in result['features']['temporal_features'].items()}
                },
                processing_time_ms=float((time.time() - start_time) * 1000)
            )

            logger.info(f"Audio analysis completed: {response.emotion} ({response.confidence:.3f})")
            return response

        finally:
            # Clean up temporary file
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
                logger.debug(f"Cleaned up temporary file: {tmp_path}")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in audio analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Audio analysis error: {str(e)}")