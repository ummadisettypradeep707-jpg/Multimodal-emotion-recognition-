import React, { useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import Header from './components/Header'
import Dashboard from './components/Dashboard'
import { useThemeStore } from './store/themeStore'

function App() {
  const { i18n } = useTranslation()
  const { isDark, toggleTheme } = useThemeStore()

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
    localStorage.setItem('theme', isDark ? 'dark' : 'light')
  }, [isDark])

  return (
    <div className="min-h-screen bg-light-bg dark:bg-dark-bg">
      <Header isDark={isDark} onThemeToggle={toggleTheme} />
      <Dashboard />
    </div>
  )
}

export default App