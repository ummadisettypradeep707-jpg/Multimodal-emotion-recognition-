import time
from typing import Dict, Optional
from langdetect import detect, DetectorFactory
from textblob import TextBlob
from app.utils.logger import setup_logger

logger = setup_logger(__name__)
DetectorFactory.seed = 0


class TextProcessor:
    """Process text data for emotion analysis"""

    EMOTION_KEYWORDS = {
        'joy': ['happy', 'glad', 'joy', 'delighted', 'pleased', 'wonderful', 'excellent'],
        'sadness': ['sad', 'unhappy', 'miserable', 'depressed', 'lonely', 'desperate'],
        'anger': ['angry', 'furious', 'rage', 'mad', 'livid', 'furious'],
        'fear': ['afraid', 'scared', 'frightened', 'terrified', 'worried'],
        'surprise': ['surprised', 'shocked', 'amazed', 'astonished'],
        'disgust': ['disgusting', 'disgusted', 'repulsed'],
        'neutral': ['okay', 'fine', 'whatever', 'sure']
    }

    def __init__(self):
        self.emotion_keywords = self.EMOTION_KEYWORDS

    def detect_language(self, text: str) -> str:
        """
        Detect language of input text

        Args:
            text: Input text

        Returns:
            Language code (e.g., 'en', 'es', 'fr')
        """
        try:
            language = detect(text)
            logger.info(f"Detected language: {language}")
            return language
        except Exception as e:
            logger.error(f"Language detection error: {str(e)}")
            return "en"  # Default to English

    def extract_features(self, text: str) -> Dict:
        """
        Extract text features for emotion analysis

        Args:
            text: Input text

        Returns:
            Dictionary containing text features
        """
        start_time = time.time()

        blob = TextBlob(text)

        features = {
            'polarity': blob.sentiment.polarity,  # Range: -1.0 to 1.0
            'subjectivity': blob.sentiment.subjectivity,  # Range: 0.0 to 1.0
            'word_count': len(text.split()),
            'char_count': len(text),
            'sentence_count': len(blob.sentences),
            'extraction_time_ms': (time.time() - start_time) * 1000
        }

        logger.debug(f"Extracted features: {features}")
        return features

    def polarity_to_emotion(self, polarity: float, subjectivity: float) -> Dict[str, float]:
        """
        Convert polarity and subjectivity scores to emotion scores

        Args:
            polarity: Polarity score (-1 to 1)
            subjectivity: Subjectivity score (0 to 1)

        Returns:
            Dictionary of emotion scores
        """
        emotion_scores = {}

        # High positive polarity -> joy
        emotion_scores['joy'] = max(0, polarity) * (1 - abs(polarity - subjectivity) * 0.5)

        # High negative polarity -> sadness/anger
        neg_polarity = abs(min(0, polarity))
        emotion_scores['sadness'] = neg_polarity * (1 - subjectivity)
        emotion_scores['anger'] = neg_polarity * subjectivity

        # High subjectivity -> surprise/fear
        emotion_scores['surprise'] = subjectivity * (abs(polarity) * 0.3)
        emotion_scores['fear'] = subjectivity * (neg_polarity * 0.5)

        # Low polarity + low subjectivity -> neutral
        emotion_scores['neutral'] = max(0, 1 - abs(polarity) - subjectivity * 0.5)

        # Normalize
        total = sum(emotion_scores.values())
        if total > 0:
            emotion_scores = {k: v / total for k, v in emotion_scores.items()}

        return emotion_scores

    def keyword_matching(self, text: str) -> Dict[str, float]:
        """
        Perform emotion recognition using keyword matching

        Args:
            text: Input text (lowercased)

        Returns:
            Dictionary of emotion scores
        """
        text_lower = text.lower()
        emotion_scores = {emotion: 0.0 for emotion in self.emotion_keywords.keys()}

        for emotion, keywords in self.emotion_keywords.items():
            for keyword in keywords:
                emotion_scores[emotion] += text_lower.count(keyword)

        # Normalize
        total = sum(emotion_scores.values())
        if total > 0:
            emotion_scores = {k: v / total for k, v in emotion_scores.items()}
        else:
            emotion_scores['neutral'] = 1.0

        return emotion_scores

    def process(self, text: str) -> Dict:
        """
        Complete text processing pipeline

        Args:
            text: Input text

        Returns:
            Dictionary containing all extracted features and emotions
        """
        start_time = time.time()

        # Detect language
        language = self.detect_language(text)

        # Extract features
        features = self.extract_features(text)

        # Get emotion scores from polarity
        polarity_emotions = self.polarity_to_emotion(
            features['polarity'],
            features['subjectivity']
        )

        # Get emotion scores from keywords
        keyword_emotions = self.keyword_matching(text)

        # Combine scores (70% polarity, 30% keywords)
        combined_emotions = {}
        for emotion in polarity_emotions.keys():
            combined_emotions[emotion] = (
                    polarity_emotions[emotion] * 0.7 +
                    keyword_emotions.get(emotion, 0) * 0.3
            )

        # Get primary emotion
        primary_emotion = max(combined_emotions, key=combined_emotions.get)
        confidence = combined_emotions[primary_emotion]

        result = {
            'primary_emotion': primary_emotion,
            'confidence': confidence,
            'emotion_scores': combined_emotions,
            'language': language,
            'features': features,
            'processing_time_ms': (time.time() - start_time) * 1000
        }

        logger.info(f"Text processing result: emotion={primary_emotion}, confidence={confidence:.3f}")
        return result