import React, { useContext } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { ThemeContext } from '../context/ThemeContext';

const colors = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4', '#f97316'];

const ConfidenceChart = ({ emotions }) => {
  const { isDarkMode } = useContext(ThemeContext);

  if (!emotions) return null;

  const data = Object.entries(emotions).map(([emotion, confidence]) => ({
    name: emotion.charAt(0).toUpperCase() + emotion.slice(1),
    confidence: (confidence * 100).toFixed(1),
  }));

  return (
    <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
      <h3 className={`font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        Alternative Emotions
      </h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#444' : '#ccc'} />
          <XAxis dataKey="name" stroke={isDarkMode ? '#aaa' : '#666'} />
          <YAxis stroke={isDarkMode ? '#aaa' : '#666'} />
          <Tooltip
            contentStyle={{
              backgroundColor: isDarkMode ? '#333' : '#fff',
              border: `1px solid ${isDarkMode ? '#555' : '#ccc'}`,
              color: isDarkMode ? '#fff' : '#000',
            }}
          />
          <Bar dataKey="confidence" fill="#6366f1" radius={[8, 8, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ConfidenceChart;