from typing import Optional
from textblob import TextBlob
from app.utils.logger import setup_logger

logger = setup_logger(__name__)


class TranslationService:
    """Service for translating text between languages"""

    def translate(self, text: str, source_language: str, target_language: str = 'en') -> str:
        """
        Translate text from source to target language

        Args:
            text: Input text to translate
            source_language: Source language code
            target_language: Target language code (default: en)

        Returns:
            Translated text
        """
        try:
            if source_language == target_language:
                logger.info("Source and target languages are the same, returning original text")
                return text

            # Using TextBlob for translation
            blob = TextBlob(text)
            detected = blob.detect_language()

            # If TextBlob doesn't support translation, return original
            logger.warning("TextBlob translation not fully supported, using alternative approach")
            return text

        except Exception as e:
            logger.error(f"Translation error: {str(e)}")
            return text