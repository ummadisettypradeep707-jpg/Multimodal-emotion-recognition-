import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'
import { FiSend, FiTrash2 } from 'react-icons/fi'
import { textAnalysis } from '../../services/api'
import { useEmotionStore } from '../../store/emotionStore'
import EmotionResult from '../EmotionResult'
import LoadingSpinner from '../LoadingSpinner'
import ErrorAlert from '../ErrorAlert'

const TextTab = () => {
  const { t } = useTranslation()
  const [text, setText] = useState('')
  const [language, setLanguage] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const [result, setResult] = useState(null)
  const addToHistory = useEmotionStore((state) => state.addToHistory)

  const handleAnalyze = async () => {
    if (!text.trim()) {
      setError(t('common.error') + ': Empty text')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await textAnalysis(text, language)
      setResult(response)
      addToHistory({
        type: 'text',
        text: text.substring(0, 100),
        emotion: response.emotion,
        confidence: response.confidence,
      })
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  const handleClear = () => {
    setText('')
    setResult(null)
    setError(null)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Input Panel */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-light-card dark:bg-dark-card rounded-lg p-6 shadow-md border border-light-border dark:border-dark-border"
      >
        <h2 className="text-xl font-bold mb-4">{t('text.title')}</h2>

        <div className="space-y-4">
          {/* Text Area */}
          <div>
            <label className="block text-sm font-medium mb-2">{t('text.placeholder')}</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t('text.placeholder')}
              className="w-full h-32 px-4 py-2 rounded-lg border border-light-border dark:border-dark-border bg-light-bg dark:bg-dark-bg text-light-text dark:text-dark-text focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />
            <p className="text-xs text-gray-500 mt-1">{text.length} characters</p>
          </div>

          {/* Language Select */}
          <div>
            <label className="block text-sm font-medium mb-2">{t('text.language')}</label>
            <select
              value={language || ''}
              onChange={(e) => setLanguage(e.target.value || null)}
              className="w-full px-4 py-2 rounded-lg border border-light-border dark:border-dark-border bg-light-bg dark:bg-dark-bg text-light-text dark:text-dark-text focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Auto-detect</option>
              <option value="en">English</option>
              <option value="es">Spanish</option>
              <option value="fr">French</option>
              <option value="de">German</option>
              <option value="it">Italian</option>
            </select>
          </div>

          {/* Error Alert */}
          {error && <ErrorAlert message={error} onClose={() => setError(null)} />}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <motion.button
              onClick={handleAnalyze}
              disabled={isLoading || !text.trim()}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <FiSend />
              {isLoading ? t('common.loading') : t('text.analyze')}
            </motion.button>

            <motion.button
              onClick={handleClear}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
            >
              <FiTrash2 />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Result Panel */}
      {isLoading ? (
        <LoadingSpinner />
      ) : result ? (
        <EmotionResult result={result} modality="text" />
      ) : (
        <div className="flex items-center justify-center bg-light-border dark:bg-dark-border rounded-lg p-6 text-gray-500">
          <p>{t('common.loading')}...</p>
        </div>
      )}
    </div>
  )
}

export default TextTab