from fastapi import APIRouter
from config import settings
from app.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter(prefix="/api", tags=["health"])


@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": settings.APP_VERSION,
        "timestamp": "2024-02-17T12:00:00",
        "models_loaded": {
            "text_processor": True,
            "audio_processor": True,
            "image_processor": True,
            "fusion_processor": True
        }
    }