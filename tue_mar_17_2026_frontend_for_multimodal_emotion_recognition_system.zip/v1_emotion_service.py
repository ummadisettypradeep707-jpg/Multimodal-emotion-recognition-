from typing import Dict, List
from app.processors.text_processor import TextProcessor
from app.processors.audio_processor import AudioProcessor
from app.processors.image_processor import ImageProcessor
from app.processors.fusion_processor import FusionProcessor
from app.utils.logger import setup_logger

logger = setup_logger(__name__)


class EmotionService:
    """Service for managing emotion recognition across modalities"""

    def __init__(self):
        self.text_processor = TextProcessor()
        self.audio_processor = AudioProcessor()
        self.image_processor = ImageProcessor()
        self.fusion_processor = FusionProcessor()
        logger.info("EmotionService initialized with all processors")

    def analyze_text(self, text: str, language: str = None) -> Dict:
        """Analyze text for emotion"""
        return self.text_processor.process(text)

    def analyze_audio(self, audio_path: str) -> Dict:
        """Analyze audio for emotion"""
        return self.audio_processor.process(audio_path)

    def analyze_image(self, image_path: str, detect_multiple: bool = False) -> Dict:
        """Analyze image for emotion"""
        return self.image_processor.process(image_path, detect_multiple)

    def fuse_emotions(self, modality_results: Dict, fusion_mode: str = None) -> Dict:
        """Fuse emotions from multiple modalities"""
        return self.fusion_processor.process(modality_results, fusion_mode)