import React, { useContext } from 'react';
import { ThemeContext } from '../context/ThemeContext';

const emotionEmojis = {
  joy: '😊',
  happy: '😊',
  sadness: '😢',
  sad: '😢',
  anger: '😠',
  angry: '😠',
  fear: '😨',
  fearful: '😨',
  surprise: '😮',
  surprised: '😮',
  disgust: '🤢',
  disgusted: '🤢',
  neutral: '😐',
};

const EmotionCard = ({ emotion, confidence }) => {
  const { isDarkMode } = useContext(ThemeContext);
  const emoji = emotionEmojis[emotion.toLowerCase()] || '❓';
  const percentage = (confidence * 100).toFixed(1);

  return (
    <div className={`p-6 rounded-lg border-2 text-center ${
      isDarkMode
        ? 'bg-gradient-to-r from-purple-900 to-blue-900 border-purple-600'
        : 'bg-gradient-to-r from-purple-100 to-blue-100 border-purple-300'
    }`}>
      <p className="text-5xl mb-3">{emoji}</p>
      <p className={`text-3xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        {emotion.charAt(0).toUpperCase() + emotion.slice(1)}
      </p>
      <p className={`text-xl font-semibold ${isDarkMode ? 'text-gray-200' : 'text-gray-700'}`}>
        Confidence: {percentage}%
      </p>
      <div className="w-full bg-gray-300 rounded-full h-2 mt-4 overflow-hidden">
        <div
          className="bg-gradient-to-r from-green-400 to-blue-500 h-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default EmotionCard;