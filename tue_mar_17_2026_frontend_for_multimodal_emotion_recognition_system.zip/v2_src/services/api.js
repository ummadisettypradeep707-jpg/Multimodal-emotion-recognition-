import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000/api';
const WS_BASE_URL = process.env.REACT_APP_WS_BASE_URL || 'ws://localhost:8000';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Text Analysis
export const analyzeText = (text, language = null) => {
  return apiClient.post('/analyze-text', {
    text,
    language,
  });
};

// Audio Analysis
export const analyzeAudio = (audioFile) => {
  const formData = new FormData();
  formData.append('file', audioFile);
  return apiClient.post('/analyze-audio', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

// Image Analysis
export const analyzeImage = (imageFile, detectMultipleFaces = false) => {
  const formData = new FormData();
  formData.append('file', imageFile);
  formData.append('detect_multiple_faces', detectMultipleFaces);
  return apiClient.post('/analyze-image', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

// Fusion Analysis
export const fusionAnalysis = (modality_results, fusion_mode = 'weighted_average') => {
  return apiClient.post('/fusion', {
    modality_results,
    fusion_mode,
  });
};

// WebSocket connections
export const connectAudioStream = (onMessage, onError) => {
  const ws = new WebSocket(`${WS_BASE_URL}/ws/live-audio`);
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    onMessage(data);
  };
  
  ws.onerror = (error) => {
    onError(error);
  };
  
  return ws;
};

export const connectVideoStream = (onMessage, onError) => {
  const ws = new WebSocket(`${WS_BASE_URL}/ws/live-video`);
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    onMessage(data);
  };
  
  ws.onerror = (error) => {
    onError(error);
  };
  
  return ws;
};