import { useRef, useState, useCallback, useEffect } from 'react'

export const useWebcam = () => {
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const [isStreaming, setIsStreaming] = useState(false)
  const [error, setError] = useState(null)

  const startWebcam = useCallback(async () => {
    try {
      setError(null)
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: false,
      })

      streamRef.current = stream

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.onloadedmetadata = () => {
          videoRef.current.play()
        }
      }

      setIsStreaming(true)
    } catch (err) {
      setError(err.message)
      console.error('Error accessing webcam:', err)
    }
  }, [])

  const stopWebcam = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      setIsStreaming(false)
    }
  }, [])

  const captureFrame = useCallback(() => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas')
      canvas.width = videoRef.current.videoWidth
      canvas.height = videoRef.current.videoHeight
      const ctx = canvas.getContext('2d')
      ctx.drawImage(videoRef.current, 0, 0)
      return canvas.toDataURL('image/jpeg')
    }
    return null
  }, [])

  useEffect(() => {
    return () => {
      stopWebcam()
    }
  }, [stopWebcam])

  return {
    videoRef,
    isStreaming,
    error,
    startWebcam,
    stopWebcam,
    captureFrame,
  }
}