import { useRef, useCallback, useEffect, useState } from 'react'

export const useWebSocket = (url) => {
  const wsRef = useRef(null)
  const [isConnected, setIsConnected] = useState(false)
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  const connect = useCallback(() => {
    try {
      const ws = new WebSocket(url)

      ws.onopen = () => {
        setIsConnected(true)
        setError(null)
      }

      ws.onmessage = (event) => {
        try {
          const receivedData = JSON.parse(event.data)
          setData(receivedData)
        } catch (e) {
          console.error('Error parsing WebSocket message:', e)
        }
      }

      ws.onerror = (event) => {
        setError('WebSocket error occurred')
        console.error('WebSocket error:', event)
      }

      ws.onclose = () => {
        setIsConnected(false)
      }

      wsRef.current = ws
    } catch (err) {
      setError(err.message)
    }
  }, [url])

  const disconnect = useCallback(() => {
    if (wsRef.current) {
      wsRef.current.close()
      setIsConnected(false)
    }
  }, [])

  const send = useCallback((message) => {
    if (wsRef.current && isConnected) {
      wsRef.current.send(JSON.stringify(message))
    }
  }, [isConnected])

  useEffect(() => {
    return () => {
      disconnect()
    }
  }, [disconnect])

  return {
    isConnected,
    data,
    error,
    connect,
    disconnect,
    send,
  }
}