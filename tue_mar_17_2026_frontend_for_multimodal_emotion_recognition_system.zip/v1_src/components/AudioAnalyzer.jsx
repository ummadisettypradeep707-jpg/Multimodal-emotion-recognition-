import React, { useContext, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useEmotionAnalysis } from '../hooks/useEmotionAnalysis';
import { useMediaRecorder } from '../hooks/useMediaRecorder';
import EmotionCard from './EmotionCard';
import ConfidenceChart from './ConfidenceChart';
import { ThemeContext } from '../context/ThemeContext';

const AudioAnalyzer = () => {
  const { t } = useTranslation();
  const { isDarkMode } = useContext(ThemeContext);
  const [audioFile, setAudioFile] = useState(null);
  const { loading, error, result, analyzeAudioFile } = useEmotionAnalysis();
  const { isRecording, recordedBlob, startRecording, stopRecording } = useMediaRecorder();

  const handleFileUpload = async (file) => {
    setAudioFile(file);
    await analyzeAudioFile(file);
  };

  const handleRecordedAudio = async () => {
    if (recordedBlob) {
      const file = new File([recordedBlob], 'recorded.wav', { type: 'audio/wav' });
      await analyzeAudioFile(file);
    }
  };

  return (
    <div className={`p-6 rounded-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
      <h2 className={`text-2xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        🎵 {t('audio_analysis')}
      </h2>

      <div className="space-y-4">
        {/* File Upload */}
        <div className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer ${
          isDarkMode ? 'border-gray-600 hover:bg-gray-700' : 'border-gray-300 hover:bg-gray-50'
        } transition`}>
          <input
            type="file"
            accept="audio/*"
            onChange={(e) => e.target.files && handleFileUpload(e.target.files[0])}
            className="hidden"
            id="audio-upload"
          />
          <label htmlFor="audio-upload" className="cursor-pointer block">
            <p className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {t('upload_file')}
            </p>
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {audioFile?.name || 'No file selected'}
            </p>
          </label>
        </div>

        {/* Live Recording */}
        <div className="flex gap-2">
          <button
            onClick={startRecording}
            disabled={isRecording || loading}
            className="flex-1 bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 disabled:opacity-50 transition"
          >
            🎤 {t('start_recording')}
          </button>
          <button
            onClick={stopRecording}
            disabled={!isRecording}
            className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 disabled:opacity-50 transition"
          >
            ⏹️ {t('stop_recording')}
          </button>
          {recordedBlob && (
            <button
              onClick={handleRecordedAudio}
              disabled={loading}
              className="flex-1 bg-primary text-white py-2 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 transition"
            >
              {loading ? t('analyzing') : 'Analyze'}
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
          {t('error')}: {error}
        </div>
      )}

      {result && (
        <div className="mt-6 space-y-4">
          <EmotionCard emotion={result.emotion} confidence={result.confidence} />
          <ConfidenceChart emotions={result.alternative_emotions} />
          <div className={`p-4 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} rounded-lg`}>
            <p className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Duration: {result.duration_seconds?.toFixed(2)}s | Processing: {result.processing_time_ms?.toFixed(0)}ms
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AudioAnalyzer;