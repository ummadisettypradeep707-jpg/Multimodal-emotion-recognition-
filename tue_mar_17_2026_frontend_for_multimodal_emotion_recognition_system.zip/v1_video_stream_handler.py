import asyncio
import json
import base64
import cv2
import numpy as np
from fastapi import WebSocket, WebSocketDisconnect
from app.processors.image_processor import ImageProcessor
from app.utils.logger import setup_logger

logger = setup_logger(__name__)


class VideoStreamHandler:
    """Handle real-time video streaming via WebSocket"""

    def __init__(self):
        self.image_processor = ImageProcessor()
        self.frame_count = 0
        self.process_every_n_frames = 5  # Process every 5th frame for efficiency

    async def handle_connection(self, websocket: WebSocket):
        """
        Handle WebSocket connection for video streaming

        Args:
            websocket: WebSocket connection object
        """
        await websocket.accept()
        logger.info("WebSocket video connection established")

        try:
            while True:
                # Receive message from client
                data = await websocket.receive_text()
                message = json.loads(data)

                if message['type'] == 'video_frame':
                    self.frame_count += 1
                    frame_id = message.get('frame_id', self.frame_count)

                    try:
                        # Decode base64 image data
                        frame_data = base64.b64decode(message['frame_data'])
                        frame_array = np.frombuffer(frame_data, dtype=np.uint8)
                        frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)

                        # Convert BGR to RGB
                        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                        logger.debug(f"Received video frame {frame_id}")

                        # Process every nth frame for efficiency
                        if self.frame_count % self.process_every_n_frames == 0:
                            # Detect faces
                            faces = self.image_processor.detect_faces(frame_rgb)

                            if faces:
                                # Process each face
                                face_results = []

                                for face in faces:
                                    features = self.image_processor.extract_facial_features(face['region'])
                                    emotion_scores = self.image_processor.face_features_to_emotion(features)

                                    primary_emotion = max(emotion_scores, key=emotion_scores.get)
                                    confidence = emotion_scores[primary_emotion]

                                    face_results.append({
                                        'face_id': face['face_id'],
                                        'emotion': primary_emotion,
                                        'confidence': float(confidence),
                                        'bounding_box': face['bounding_box']
                                    })

                                # Send results
                                result = {
                                    'type': 'emotion_result',
                                    'frame_id': frame_id,
                                    'faces_detected': len(faces),
                                    'face_results': face_results
                                }

                                await websocket.send_text(json.dumps(result))
                                logger.info(f"Sent video emotion result: {len(faces)} faces detected")
                            else:
                                # No faces detected
                                result = {
                                    'type': 'emotion_result',
                                    'frame_id': frame_id,
                                    'faces_detected': 0,
                                    'face_results': []
                                }
                                await websocket.send_text(json.dumps(result))

                    except Exception as e:
                        error_msg = {
                            'type': 'error',
                            'message': f"Error processing video frame: {str(e)}"
                        }
                        await websocket.send_text(json.dumps(error_msg))
                        logger.error(f"Error processing video frame: {str(e)}")

        except WebSocketDisconnect:
            logger.info("WebSocket video connection closed")
        except Exception as e:
            logger.error(f"WebSocket error: {str(e)}")
            try:
                await websocket.close(code=1011, reason=str(e))
            except:
                pass